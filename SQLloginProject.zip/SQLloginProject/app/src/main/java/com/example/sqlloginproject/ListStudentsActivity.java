package com.example.sqlloginproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import com.example.sqlloginproject.adapter.StudentAdapter;
import com.example.sqlloginproject.db.DbHelper;
import com.example.sqlloginproject.model.Student;

import java.util.ArrayList;

public class ListStudentsActivity extends AppCompatActivity implements StudentAdapter.OnItemClickListener {

    private RecyclerView recyclerView;
    private StudentAdapter adapter;
    private ArrayList<Student> studentsArrayList;
    private DbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_student);

        recyclerView = findViewById(R.id.recyclerView);
        dbHelper = new DbHelper(this);
        studentsArrayList = new ArrayList<>();
        adapter = new StudentAdapter(studentsArrayList);
        adapter.setOnItemClickListener(this);

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);

        loadStudentsData();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadStudentsData();
    }

    private void loadStudentsData() {
        studentsArrayList.clear(); // Clear the list before loading new data
        studentsArrayList.addAll(dbHelper.getAllUsers());
        adapter.notifyDataSetChanged(); // Notify adapter about data change
    }

    @Override
    protected void onDestroy() {
        dbHelper.close(); // Close the database connection when the activity is destroyed
        super.onDestroy();
    }

    @Override
    public void onItemClick(int position) {
        // Handle item click here if needed
    }

    @Override
    public void onEditClick(int position) {
        // Mendapatkan objek Student dari studentsArrayList sesuai dengan posisi yang diklik
        Student student = studentsArrayList.get(position);

        // Membuat Intent untuk membuka UpdateActivity dan menyertakan objek Student sebagai data
        Intent intent = new Intent(ListStudentsActivity.this, UpdateActivity.class);
        intent.putExtra("user", student);
        startActivity(intent);
    }


    @Override
    public void onDeleteClick(int position) {
        Student deletedStudent = studentsArrayList.get(position);
        dbHelper.deleteUser(deletedStudent.getId());
        studentsArrayList.remove(position);
        adapter.notifyItemRemoved(position);
        Toast.makeText(this, "Student deleted", Toast.LENGTH_SHORT).show();
    }
}